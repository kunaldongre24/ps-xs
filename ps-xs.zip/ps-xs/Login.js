import React from "react";
import "../style/Login.css";

function Login() {
  return (
    <div className="login">
      <form>
        <div className="login-header">
          <div style={{ width: "50%", fontSize: "24px" }}>Login</div>
          <div className="logo"></div>
        </div>

        <div className="field">
          <label>Username</label>
          <input type="name" />
        </div>
        <div className="field">
          <label>Password</label>
          <input type="password" />
        </div>
        <input type="submit" value="Log in" className="loginBtn" />
      </form>
    </div>
  );
}

export default Login;
