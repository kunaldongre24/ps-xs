import React, { useState, useEffect } from "react";
import Content from "./Components/Content";
import "./style/index.css";
import "./style/App.css";
import Login from "./Components/Login";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

function App() {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1328);

  const closeModal = () => {
    const element = document.getElementsByClassName("modal");
    element[0].style.display = "none";
  };
  useEffect(() => {
    window.addEventListener(
      "resize",
      () => {
        const ismobile = window.innerWidth < 1328;
        if (ismobile !== isMobile) setIsMobile(ismobile);
      },
      false
    );
  }, [isMobile]);

  return (
    <div className="App">
      <div className="strip"></div>
      <div class="modal">
        <div class="modal-body">
          <span className="close" onClick={closeModal}>
            &#x2715;
          </span>
          <div class="modalcontent"></div>
        </div>
      </div>
      <Router>
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/" render={() => <Content isMobile={isMobile} />} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
